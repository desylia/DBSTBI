
<html>
<title>Form Upload</title>
<body>
<div id="content">
<form enctype="multipart/form-data" method="POST" action="?menu=hasil_upload">
<p align="center"><b>FILE UPLOAD</b></p> 
<table width="459" border="0" align="center">
  <tr>
    <td width="139">File yang di upload :</td>
    <td width="310"><input type="file" name="fupload"></td>
  </tr>
  <tr>
    <td>Deskripsi File :</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><textarea name="deskripsi" rows="8" cols="40"></textarea></td>
    </tr>
  <tr>
    <td colspan="2"><input type=submit value=Upload></td>
    </tr>
</table><br>
</form>
</div>
</body>
</html>
