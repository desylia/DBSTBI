<html>
<title>Query</title>
<body>
<div id="content">
<form enctype="multipart/form-data" method="POST" action="?menu=hasilquery">
  <table width="334" border="0" align="center">
    <tr>
    <td colspan="2">Kata Kunci :</td>
    </tr>
  <tr>
    <td width="144"><input type="text" name="katakunci"></td>
    <td width="180"><input type=submit value="Cari Query"></td>
  </tr>
  <tr>
    <td colspan="2"></td>
    </tr>
</table>
</form>
</div>
</body>
</html>