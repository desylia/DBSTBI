<html>
<body>
<div id="content">
<h1>INFORMATION RETRIEVAL</h1>
<br>
Siti Aisyah
<br>
14.01.55.0050
<br>
<br>
Desylia Eka Nabela Putri
<br>
14.01.55.0056
<br>
<br>
Annisa Masruroh
<br>
14.01.55.0063
</div>
</body>
</html>
